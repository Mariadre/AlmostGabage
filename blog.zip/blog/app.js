var express = require('express');
var app = express();
var logger = require('morgan');
//var cookieParser = require('cookie-parser');
//var session = require('express-session');
var methodOverride = require('method-override');
var post = require('./routes/post');


// template engine
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

// middle ware
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
// X-HTTP-method-override
app.use(methodOverride((req, res) => {
  if (req.body && 
      typeof req.body === 'object' && 
     '_method' in req.body) {
    var method = req.body._method;
    delete req.body._method;
    return method;
  }
}));

// csrf
//app.use(cookieParser());
//var session_opt = {
//  secret: '43VW9&92DEF32S23',
//  resave: false,
//  saveUninitialized: false,
//  cookie: { maxAge: 60 * 60 * 1000 },
//};
//app.use(session(session_opt));
//app.use(express.csrf());
//app.use((req, res, next) => {
//  res.locals.csrftoken = req.csrfToken();
//  next();
//});


// routing
app.get('/', post.index);
app.get('/posts/:id([0-9]+)', post.show);
app.get('/posts/new', post.new);
app.post('/posts/create', post.create);
app.get('/posts/:id/edit', post.edit);
app.put('/posts/:id', post.update);
app.delete('/posts/:id', post.destroy);

// error handler
app.use((err, req, res, next) => {
  res.status(400);
  res.send(err.message);
  // never next()
});

app.listen(3000);
console.log('Server Start.');
