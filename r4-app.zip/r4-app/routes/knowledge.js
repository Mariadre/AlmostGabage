var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {

  var err = new Error('Bad Request');
  err.statusCode = 400;
  next(err);


  // res.render('knowledge', {
  //   title: 'Knowledge',
  //   contents: 'Knowledge page'
  // });
});

router.get('/ugaki', function(req, res, next) {
  req.body = 'BODY';
  req.checkBody().notEmpty();
  req.checkBody().isJSON();
  req.getValidationResult().then((result) => {
    if (!result.isEmpty()) {
      results = result.array();
      for (var n in results) {
        console.log('param:', results[n].param);
        console.log('msg:', results[n].msg);
        console.log('value:', results[n].value);
      }
      var err = new Error('Baaaaaaaaaaad Request');
      err.statusCode = 404;
      next(err);    
    } else {
      res.send({
        status: 200,
        message: 'good !'
      });
    }
  })
});

module.exports = router;
