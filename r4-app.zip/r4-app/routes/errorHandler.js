/*
 * GET home page.
 */
exports.notFound = function(req, res, next) {
  console.log('------ 404 ------');
  var err = new Error('Not Found');
  err.statusCode = 404;
  next(err);
}

exports.clientErrorHandler = function(err, req, res, next){

  console.log('*************** clientErrorHandler ***************');
  // var err = new Error('test');
  // err.statusCode = 404;
  // next(err);
  if (err.statusCode) {
      res.status(err.statusCode).send({
        status: err.statusCode,
        message: err.message
      });
  } else {
    console.log('------ CAN NOT HANDLING @clientErrorHandler() ------');
    next(err);
  }

  // res.statusCode = 404;
  // res.send({ 
  //   status: '404',
  //   message: 'Resource not found'
  //  });

  // res.status(404).format({
  //     html: function(){
  //       res.render('404');
  //     },
  //     json: function(){
  //       res.send({ message: 'Resource not found' });
  //     },
  //     xml: function() {
  //       res.write('<error>\n');
  //       res.write(' <message>Resource not found</message>\n');
  //       res.end('</error>\n');
  //     },
  //     text: function(){
  //       res.send('Resource not found\n');
  //     }
  //   });
  };
  
  exports.error = function(err, req, res, next){
    console.log('*************** catch-all errorHandler ***************');
    console.error(err.stack);
    // var msg;

    console.log('------ 500 ------');
    res.status(500).send({
      status: '500',
      message: 'Internal Server Error'
    });

    // switch (err.type) {
    //   case 'database':
    //     msg = 'Server Unavailable';
    //     res.statusCode = 503;
    //     break;
  
    //   default:
    //     msg = 'Internal Server Error';
    //     res.statusCode = 500;
    // }
  
    // res.format({
    //   html: function(){
    //     res.render('5xx', { msg: msg, status: res.statusCode });
    //   },
  
    //   json: function(){
    //     res.send({ error: msg });
    //   },
  
    //   text: function(){
    //     res.send(msg + '\n');
    //   }
    // });
  };
  