var express = require('express');
var fs = require('fs');
const proc = require('child_process');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('result', {
    title: 'Result(GET)',
    contents: 'Result page'
  });
});

// e.g.)
//{
//  fieldname: 'file',
//  originalname: '51b9b572a6a0737105.jpg',
//  encoding: '7bit',
//  mimetype: 'image/jpeg',
//  destination: './tmp/',
//  filename: '93f02f7e6436bdcdc55d518dfa240ab8',
//  path: 'tmp/93f02f7e6436bdcdc55d518dfa240ab8',
//  size: 216147
//}
router.post('/', function (req, res, next) {
  response = null;
  var data = null;
  var file = __dirname + "/uploads" + req.file.originalname; // fullpath
  fs.readFile(req.file.path, function (err, data) {
    fs.writeFile(file, data, function (err) {
      if (err || req.file.originalname.indexOf('.csv') == -1) {
        console.log(err);
      } else {
        response = {
          message: 'UPLOAD SUCCESS',
          filename: req.file.filename,
          filetype: req.file.mimetype,
          originalname: req.file.originalname,
        };
        
        /* ****************************************** */
        var spawn = proc.spawn;
        var py = spawn('python', ['python/test.py']);
        var data = {
          "form_data": {
            algorithm: req.body.algorithm,
            committed: req.body.committed,
          },
          "upload_file": response,
        };
        var dataString = '';

        py.stdout.on('data', function (data) {
          dataString += data.toString();
          console.log('send data to python');
        });
        py.stderr.on('data', function (data) {
          dataString += data.toString();
          console.log('Error:' + dataString);
        });

        py.stdout.on('end', function () {
          console.log(dataString);
        });

        py.stdin.write(JSON.stringify(data));
        py.stdin.end();
        /* ****************************************** */
      }
      console.log(response);
      res.end(JSON.stringify(response));
    });
  });
  
  res.render('result', {
    title: 'Result',
    contents: 'Result page'
  });
});

module.exports = router;