var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('model_selection', {
    title: 'Model Selection',
    contents: 'model selection page'
  });
});

module.exports = router;
