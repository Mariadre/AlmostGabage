var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {

  var i = dummy();
  // res.render('data_analytics', {
  //   title: 'Data Analytics',
  //   contents: 'Data Analytics page'
  // });
});

module.exports = router;
