import sys
import time
import json
import pandas as pd
import numpy as np

from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.pipeline import make_pipeline


now = time.time()


def export_log(text, prefix=''):
    file_name = './python/log/log_{}.txt'.format(now)
    with open(file_name, 'a') as f:
        f.write(prefix + str(text) + '\n')
        f.flush()


def read_stdin():
    json_params = sys.stdin.readline()
    # export_log(json_params, 'stdin: ')

    return json.loads(json_params)


def fit():
    json_params = read_stdin()
    # export_log(json_params, 'json: ')

    file_name = json_params['upload_file']['filename']
    file_path = './uploads/' + file_name
    df = pd.read_csv(file_path).dropna()
    data = df[list(df.columns)[:len(df.columns)-1]].as_matrix()
    target = df[list(df.columns)[-1]].as_matrix()

    form_data = json_params['form_data']
    if form_data['algorithm'] == 'svm':


    elif form_data['algorithm'] == 'knn':

    else:
        pass


    if form_data.get('committed'):
        committed = True
    else:
        committed = False



    # dict 型データに対するバリデートなども必要
    # new_iris_data = np.array([list(json_params.values())])
    #
    # model = joblib.load('model.pkl')  # 97.4%
    # prediction = model.predict(new_iris_data)[0]
    #
    # # export_log(prediction, 'prediction: ')
    # print(class_dict[prediction])
    print(df.head())


if __name__ == '__main__':
    fit()
